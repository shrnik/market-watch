import React, { Component } from "react";
import ListItem from "./listItem";
import { DropDownItem } from "./dropdownItem";

class List extends Component {
  constructor(props) {
    super(props);
    this.state = {
      // data: [
      //   { symbol: "BTC", tsym: "USD", market: "OKCoin" },
      //   { symbol: "BTC", tsym: "USD", market: "NSE" },
      //   { symbol: "BTC", tsym: "USD", market: "AbuCoin" },
      //   { symbol: "BTC", tsym: "USD", market: "cryptsy" }
      // ],
      market: [
        "Abucoins",
        "BTCAlpha",
        "BTCChina",
        "BTCE",
        "BitBay",
        "BitFlip",
        "BitSquare",
        "BitTrex",
        "BitexBook",
        "Bitfinex",
        "Bitlish",
        "Bitsane",
        "Bitstamp",
        "CCEDK",
        "CCEX",
        "Cexio",
        "CoinDeal",
        "CoinHub",
        "Coinbase",
        "Coincap",
        "Coinfloor",
        "Coinroom",
        "CoinsBank",
        "Coinsbit",
        "Coinsetter",
        "Cryptsy",
        "DSX",
        "Exenium",
        "Exmo",
        "ExtStock",
        "Gatecoin",
        "Gemini",
        "Graviex",
        "Huobi",
        "Incorex",
        "IndependentReserve",
        "Kraken",
        "LakeBTC",
        "Liquid",
        "LiveCoin",
        "LocalBitcoins",
        "Lykke",
        "MonetaGo",
        "Neraex",
        "OKCoin",
        "Ore",
        "P2PB2B",
        "Poloniex",
        "QuadrigaCX",
        "Quoine",
        "Remitano",
        "RightBTC",
        "Simex",
        "SingularityX",
        "StocksExchange",
        "StocksExchangeio",
        "TheRockTrading",
        "TrustDEX",
        "WEX",
        "WavesDEX",
        "Yobit",
        "bitFlyer",
        "itBit"
      ],
      input: "",
      displayData: []
    };
  }

  getInput = e => {
    e.preventDefault();
    this.setState({ input: e.target.value }, () => {
      console.log(this.state.input);
    });
  };

  handleDropDownclick = (e, item) => {
    //   e.preventDefault();
    let newDislayData = this.state.displayData;
    newDislayData.push(item);
    this.setState({ displayData: newDislayData, input: "" }, () => {
      console.log(this.state);
    });
  };
  // componentDidMount(){
  //     fetch()
  // }
  render() {
    return (
      <div className="watch">
        <div className="drp">
          <input
            className="search"
            placeholder="Search for crypto"
            onChange={this.getInput}
          />
          <div className="dropdown show">
            {this.state.input !== "" &&
              this.state.market
                .filter(data => {
                  return data
                    .toLowerCase()
                    .includes(this.state.input.toLowerCase());
                })
                .map((item, index) => {
                  return (
                    <DropDownItem
                      onClick={this.handleDropDownclick}
                      key={index}
                      item={item}
                    />
                  );
                })}
          </div>
        </div>
        <ListItem symbol="BTC" tsym="USD" market="OKCoin" />
        <ListItem symbol="BTC" tsym="US" market="OKCoin" />
        {this.state.displayData &&
          this.state.displayData.map((item, index) => {
            return <ListItem market={item} symbol="BTC" tsym="USD" key={index} />;
          })}
      </div>
    );
  }
}

export default List;
