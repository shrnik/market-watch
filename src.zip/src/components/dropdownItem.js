import React from 'react';

export const DropDownItem=(props)=>{
    return(
        <div className="dropdownItem" onClick={e=>props.onClick(e,props.item)}>{props.item}</div>
    )
}